-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2024 at 09:20 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fpl`
--

-- --------------------------------------------------------

--
-- Table structure for table `main_resources`
--

CREATE TABLE `main_resources` (
  `Resource_ID` int(11) NOT NULL,
  `item_name` varchar(255) DEFAULT NULL,
  `additional_comments` varchar(255) DEFAULT NULL,
  `item_quantity` int(11) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `main_resources`
--

INSERT INTO `main_resources` (`Resource_ID`, `item_name`, `additional_comments`, `item_quantity`, `timestamp`) VALUES
(1, 'Paper', 'Manila', 100, '2024-04-14 12:28:46'),
(2, 'Ink', 'Yellow', 5, '2024-04-14 12:28:46'),
(3, 'Ink', 'Cyan', 5, '2024-04-14 12:28:46'),
(4, 'Ink', 'Black', 5, '2024-04-14 12:28:46'),
(5, 'Ink', 'Magenta', 5, '2024-04-14 12:28:46'),
(6, 'Holographic Foil', 'Gold', 3, '2024-04-14 12:28:46'),
(7, 'Holographic Foil ', 'Silver', 3, '2024-04-14 12:28:46'),
(8, 'Holographic Foil', 'Clear', 3, '2024-04-14 12:28:46'),
(9, 'Paper', 'Eggshell', 500, '2024-04-14 12:28:46'),
(11, 'Ink', 'UV Red', 5, '2024-04-14 12:28:46');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `main_resources`
--
ALTER TABLE `main_resources`
  ADD PRIMARY KEY (`Resource_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `main_resources`
--
ALTER TABLE `main_resources`
  MODIFY `Resource_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
