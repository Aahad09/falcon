-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 12, 2024 at 11:13 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fpl`
--

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `name`, `timestamp`) VALUES
(1, 'Kenya Range Officers Institute', '2024-04-05 00:45:40'),
(2, 'South Eastern Kenya University', '2024-04-07 23:11:49'),
(3, 'International Police Organization', '2024-04-09 10:01:27'),
(4, 'Amref International University', '2024-04-17 11:46:21'),
(5, 'University of Nairobi', '2024-04-17 13:05:08'),
(6, 'Kenya Methodist University', '2024-04-17 13:32:03'),
(7, 'Machakos University', '2024-05-02 12:26:12'),
(8, 'Daystar University', '2024-05-06 12:33:52'),
(9, 'Garissa University', '2024-05-07 11:18:56'),
(10, 'Great Lakes University of Kisumu', '2024-05-16 10:47:17'),
(11, 'University of Eldoret', '2024-05-20 10:43:08'),
(12, 'Baraton College', '2024-06-11 10:48:39'),
(13, 'Maseno University', '2024-06-11 12:47:41');

-- --------------------------------------------------------

--
-- Table structure for table `general_resources`
--

CREATE TABLE `general_resources` (
  `resource_id` int(11) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `item_quantity` int(11) NOT NULL,
  `additional_comments` text DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `general_resources`
--

INSERT INTO `general_resources` (`resource_id`, `item_name`, `item_quantity`, `additional_comments`, `timestamp`) VALUES
(1, 'Cellotape', 3, '', '2024-04-08 01:02:30'),
(2, 'WD-40', 1, '', '2024-04-08 01:02:30');

-- --------------------------------------------------------

--
-- Table structure for table `job_card`
--

CREATE TABLE `job_card` (
  `id` int(11) NOT NULL,
  `Client` varchar(255) DEFAULT NULL,
  `Job_Description` text DEFAULT NULL,
  `Special_Instructions` text DEFAULT NULL,
  `Machine` varchar(255) DEFAULT NULL,
  `No_of_Plates` int(11) DEFAULT NULL,
  `Ink` varchar(255) DEFAULT NULL,
  `Paper_Type` varchar(255) DEFAULT NULL,
  `GSM` int(11) DEFAULT NULL,
  `Size` varchar(255) DEFAULT NULL,
  `Quantity_Actual` int(11) DEFAULT NULL,
  `Quantity_Overs` int(11) DEFAULT NULL,
  `Quantity_Total` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `Status` varchar(20) NOT NULL DEFAULT 'Pending',
  `Completed_Time` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_card`
--

INSERT INTO `job_card` (`id`, `Client`, `Job_Description`, `Special_Instructions`, `Machine`, `No_of_Plates`, `Ink`, `Paper_Type`, `GSM`, `Size`, `Quantity_Actual`, `Quantity_Overs`, `Quantity_Total`, `created_at`, `Status`, `Completed_Time`) VALUES
(1, 'Kenya Range Officers Institute', 'Certificates + Cards\r\nSerial RO-0071 - R0-0097', '', 'Epson AM-C5000', 0, 'Black, Yellow, Cyan, Magenta', 'Manila', 300, 'A4', 27, 3, 30, '2024-04-04 08:45:40', 'Completed', '2024-04-03 23:48:22'),
(2, 'South Eastern Kenya University', 'Corrections', '', 'Epson AM-C5000', 0, 'Black, Yellow, Cyan, Magenta', 'Eggshell', 300, 'A4', 5, 0, 5, '2024-04-07 23:11:49', 'Completed', '2024-04-16 09:05:09'),
(3, 'International Police Organization', 'Certificates + Cards. \r\nKEN-HQ-006\r\nKEN-HQ-009\r\nKEN-416', '', 'Epson AM-C5000', 0, 'Black, Yellow, Cyan, Magenta', 'Manila', 300, 'A4', 3, 0, 3, '2024-04-09 10:01:26', 'Completed', '2024-04-16 10:22:59'),
(4, 'Amref International University', 'Certificate in Strategic Leadership & Management ', '', 'Epson AM-C5000', 0, 'Black, Yellow, Cyan, Magenta', 'Manila', 300, 'A4', 26, 0, 26, '2024-04-17 11:46:21', 'Completed', '2024-04-17 10:48:48'),
(5, 'University of Nairobi', 'Corrections', '', 'Epson AM-C5000', 0, 'Black, Yellow, Cyan, Magenta', 'Manila', 300, 'A4', 118, 0, 118, '2024-04-17 13:05:08', 'Completed', '2024-04-17 12:05:51'),
(6, 'Kenya Methodist University', 'Corrections. Bachelor: 22, Diploma: 17', '', 'Epson AM-C5000', 0, 'Black, Yellow, Cyan, Magenta', 'Manila', 300, 'A4', 39, 0, 39, '2024-04-17 13:32:03', 'Completed', '2024-04-17 12:32:55'),
(7, 'Machakos University', 'Corrections', '', 'Epson AM-C5000', 0, 'Black, Yellow, Cyan, Magenta', 'Manila', 300, 'A4', 16, 0, 16, '2024-05-02 12:26:11', 'Completed', '2024-05-02 11:31:33'),
(8, 'Amref International University', 'Certificates (COC)', '', 'Epson AM-C5000', 0, 'Black, Yellow, Cyan, Magenta', 'Manila', 300, 'A4', 29, 0, 29, '2024-05-03 08:51:09', 'Completed', '2024-05-03 07:52:55'),
(9, 'Daystar University', 'Transcripts. From DST08001 - DST18000', '20 Reams', 'Epson AM-C5000', 0, 'Black, Yellow, Cyan, Magenta', 'Security Paper', 80, 'A4', 10000, 0, 10000, '2024-05-06 12:33:51', 'Completed', '2024-05-06 11:36:22'),
(10, 'Garissa University', 'Corrections', '', 'Epson AM-C5000', 0, 'Black, Yellow, Cyan, Magenta', 'Manila', 300, 'A4', 9, 0, 9, '2024-05-07 11:18:56', 'Completed', '2024-05-07 10:22:01'),
(11, 'Amref International University', 'Certificates', '', 'Epson AM-C5000', 0, 'Black, Yellow, Cyan, Magenta', 'Manila', 300, 'A4', 10, 0, 10, '2024-05-08 11:00:21', 'Completed', '2024-05-08 10:01:20'),
(12, 'Machakos University', 'Certificates', '', 'Epson AM-C5000', 0, 'Black, Yellow, Cyan, Magenta', 'Manila', 300, 'A4', 1162, 0, 1162, '2024-05-08 13:37:50', 'Completed', '2024-05-08 12:38:59'),
(13, 'Great Lakes University of Kisumu', 'Corrections', '', 'Epson AM-C5000', 0, 'Black, Yellow, Cyan, Magenta', 'Manila', 300, 'A4', 16, 0, 16, '2024-05-16 10:47:16', 'Completed', '2024-05-16 10:56:39'),
(14, 'Machakos University', 'Corrections', '', 'Epson AM-C5000', 0, 'Black, Yellow, Cyan, Magenta', 'Manila', 300, 'A4', 47, 0, 47, '2024-05-16 10:52:13', 'Completed', '2024-05-16 11:56:41'),
(15, 'University of Eldoret', 'Corrections', '', 'Epson AM-C5000', 0, 'Black, Yellow, Cyan, Magenta', 'Manila', 300, 'A4', 36, 0, 36, '2024-05-20 10:43:07', 'Completed', '2024-05-20 10:26:46'),
(16, 'Machakos University', 'Transcripts. From 41001 - 49000 (16 Reams)', '', 'Epson AM-C5000', 0, 'Black, Yellow, Cyan, Magenta', 'Security Paper', 80, 'A4', 8000, 0, 8000, '2024-05-21 10:23:04', 'Completed', '2024-05-21 11:32:44'),
(17, 'Daystar University', 'CoC', '', 'Epson AM-C5000', 0, 'Black, Yellow, Cyan, Magenta', 'Manila', 300, 'A4', 55, 0, 55, '2024-05-22 06:59:31', 'Completed', '2024-05-22 08:24:49'),
(18, 'Amref International University', 'Certificate', '', 'Epson AM-C5000', 0, 'Black, Yellow, Cyan, Magenta', 'Manila', 300, 'A4', 16, 0, 16, '2024-05-22 07:26:29', 'Completed', '2024-05-22 06:28:58'),
(19, 'Machakos University', 'Additionals', '', 'Epson AM-C5000', 0, 'Black, Yellow, Cyan, Magenta', 'Manila', 300, 'A4', 32, 0, 32, '2024-06-06 10:18:47', 'Completed', '2024-06-06 09:20:48'),
(20, 'International Police Organization', 'Certificates + Cards (KEN-417 - 420)', '', 'Epson AM-C5000', 0, 'Black, Yellow, Cyan, Magenta', 'Manila', 300, 'A4', 4, 0, 4, '2024-06-06 11:38:02', 'Completed', '2024-06-06 10:38:37'),
(21, 'Amref International University', 'Certificates', '', 'Epson AM-C5000', 0, 'Black, Yellow, Cyan, Magenta', 'Manila', 300, 'A4', 33, 0, 33, '2024-06-11 09:52:36', 'Completed', '2024-06-11 08:53:25'),
(22, 'Baraton College', 'Corrections', '', 'Epson AM-C5000', 0, 'Black, Yellow, Cyan, Magenta', 'Manila', 300, 'A4', 3, 0, 3, '2024-06-11 10:48:39', 'Completed', '2024-06-11 09:49:20'),
(23, 'Maseno University', 'Corrections', '', 'Epson AM-C5000', 0, 'Black, Yellow, Cyan, Magenta', 'Conqueror Vellum Board', 250, 'A4', 24, 0, 24, '2024-06-11 12:47:40', 'Completed', '2024-06-11 12:00:44');

-- --------------------------------------------------------

--
-- Table structure for table `main_resources`
--

CREATE TABLE `main_resources` (
  `Resource_ID` int(11) NOT NULL,
  `item_name` varchar(255) DEFAULT NULL,
  `additional_comments` varchar(255) DEFAULT NULL,
  `item_quantity` int(11) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `main_resources`
--

INSERT INTO `main_resources` (`Resource_ID`, `item_name`, `additional_comments`, `item_quantity`, `timestamp`) VALUES
(1, 'Paper', 'Manila', 100, '2024-04-14 12:28:46'),
(2, 'Ink', 'Yellow', 5, '2024-04-14 12:28:46'),
(3, 'Ink', 'Cyan', 5, '2024-04-14 12:28:46'),
(4, 'Ink', 'Black', 5, '2024-04-14 12:28:46'),
(5, 'Ink', 'Magenta', 5, '2024-04-14 12:28:46'),
(6, 'Holographic Foil', 'Gold', 3, '2024-04-14 12:28:46'),
(7, 'Holographic Foil ', 'Silver', 3, '2024-04-14 12:28:46'),
(8, 'Holographic Foil', 'Clear', 3, '2024-04-14 12:28:46'),
(9, 'Paper', 'Eggshell', 500, '2024-04-14 12:28:46'),
(11, 'Ink', 'UV Red', 5, '2024-04-14 12:28:46');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` enum('Admin','Workshop','Inventory') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `role`) VALUES
(1, 'Admin', 'FPLKE', 'Admin'),
(2, 'User1', 'user1_p', 'Workshop'),
(3, 'User2', 'user2_p', 'Inventory');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `general_resources`
--
ALTER TABLE `general_resources`
  ADD PRIMARY KEY (`resource_id`);

--
-- Indexes for table `job_card`
--
ALTER TABLE `job_card`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `main_resources`
--
ALTER TABLE `main_resources`
  ADD PRIMARY KEY (`Resource_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `general_resources`
--
ALTER TABLE `general_resources`
  MODIFY `resource_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `job_card`
--
ALTER TABLE `job_card`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `main_resources`
--
ALTER TABLE `main_resources`
  MODIFY `Resource_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
